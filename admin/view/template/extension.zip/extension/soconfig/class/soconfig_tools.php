<?php

 class SoconfigTools{
  
  public $registry; 
 
   public function __construct($registry){
     $this->registry = $registry;
   }
   
 }